
## Cara Instalasi
1. Pastikan di perangkat anda sudah ter-install 'Composer' dan 'Git'
2. Download Source Code
3. Buka source code di text editor anda
4. Buka terminal di text editor anda lalu ketikkan 'composer install'
5. Buat database di php myadmin dengan nama 'db-quiz'
6. Ketikkan kembali 'php artisan migrate' pada terminal.
7. Untuk menjalankan aplikasi anda cukup mengetikkan 'php artisan serve' pada terminal lalu ctrl+click pada link yang muncul

## Akun Login
email       = "admin@gmail.com";
password    = admin;

## Identitas Mahasiswa
- Nama    : Adi Gunawan Silalahi
- Nim     : 0702212056
- Kelas   : SI-1/V




